﻿using System;
using System.Text;
using System.Data;
using MySql.Data.MySqlClient;

namespace finalproject
{
    class Books
    {

        private DAL dal;

        public Books()
        {
            dal = new DAL();
        }

        public DataTable getBooks()
        {
            DataTable tbl;
            try
            {
                // string sql = "select *  from books";
                string sql = "select books.*, categories.*  from books";
                sql += " books inner join categories on ";
                sql += " books.bk_cat_ID = categories.cat_ID ";

                tbl = dal.GetData(sql, "books");

                return tbl;
            }
            catch (MySqlException ex)
            {
                throw ex;
            }

        }

        public DataTable getBooksByCatID(int catID)
        {
            DataTable tbl;
            try
            {
                string sql = "select * from books where bk_cat_ID=" + catID;
              

                tbl = dal.GetData(sql, "books");

                return tbl;
            }
            catch (MySqlException ex)
            {
                throw ex;
            }

        }

        public DataTable getBooksByCatName(string name)
        {
            DataTable tbl;
            try
            {
                string sql = "select * from books where bk_name like '" + name + "%'";


                tbl = dal.GetData(sql, "books");

                return tbl;
            }
            catch (MySqlException ex)
            {
                throw ex;
            }

        }
    }
}
