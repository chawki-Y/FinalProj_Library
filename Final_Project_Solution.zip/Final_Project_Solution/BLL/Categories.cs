﻿using System;
using System.Text;
using System.Data;
using MySql.Data.MySqlClient;

namespace finalproject
{
    public class Categories
    {
        private DAL dal;

        public Categories()
        {
            dal = new DAL();
        }

        public DataTable getCategories()
        {
            DataTable tbl;
            try
            {
                string sql = "select * from categories";


                tbl = dal.GetData(sql, "categories");

                return tbl;
            }
            catch (MySqlException ex)
            {
                throw ex;
            }

        }
    }
}
