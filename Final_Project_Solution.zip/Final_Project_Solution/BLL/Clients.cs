﻿using System;
using System.Text;
using System.Data;
using MySql.Data.MySqlClient;

namespace finalproject
{
    class Clients
    {
        private DAL dal;

        public Clients()
        {
            dal = new DAL();
        }

        public DataTable getClients()
        {
            DataTable tbl;
            try
            {
                string sql = "select u_id, client_fname as username, client_pwd as pwd, u_type from clients";


                tbl = dal.GetData(sql, "clients");

                return tbl;
            }
            catch (MySqlException ex)
            {
                throw ex;
            }

        }


        public DataRow login(string usrname, string pwd)
        {
            DataRow result = null;
            try
            {
                string sql = "select * from clients where client_fname='" + usrname + "' and client_pwd='" + pwd + "'";

                DataTable tbl = dal.GetData(sql, "clients");

                if (tbl.Rows.Count > 0)
                    //result = int.Parse(tbl.Rows[0]["u_type"].ToString());
                    result = tbl.Rows[0];
            }
            catch (MySqlException ex)
            {
                throw ex;
            }

            return result;
        }

        public void deleteClientByID(int id)
        {
            try
            {
                string sql = "delete from clients where u_id=" + id;
                dal.executeData(sql);
            }
            catch(MySqlException ex)
            {
                throw ex;
            }
        }


        public void updateClients(int id, string pwd, int utype)
        {
            try
            {
                string sql = "update clients set u_pwd='" + pwd + "' , u_type=" + utype;
                sql += " where u_id=" + id;

                dal.executeData(sql);
            }
            catch (MySqlException ex)
            {
                throw ex;
            }
        }
    }
}
