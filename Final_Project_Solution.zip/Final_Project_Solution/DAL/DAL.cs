﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using MySql.Data.MySqlClient;

namespace finalproject
{
    class DAL
    {
        #region member variables 

        private MySqlConnection conn;

        private string connectionString = "server=localhost;user id=root;database=final_project";

        private MySqlDataAdapter adap;

        #endregion

        public DAL()
        {
            conn = new MySqlConnection(connectionString);
        }


        public DataTable GetData(string sql, string tableName)
        {
            try
            {
                DataSet ds = new DataSet();

                if (conn.State != ConnectionState.Open)
                    conn.Open();

                adap = new MySqlDataAdapter(sql, conn);
                adap.Fill(ds, tableName);

                return ds.Tables[tableName];
            }
            catch (MySqlException ex)
            {

                throw ex;

            }
            finally
            {
                conn.Close();
            }

        }

        public void executeData(string sql)
        {
            try
            {
                if (conn.State != ConnectionState.Open)
                    conn.Open();

                MySqlCommand cmd = new MySqlCommand(sql, conn);
                cmd.ExecuteNonQuery();
            }
            catch (MySqlException ex)
            {
                throw ex;
            }
            finally
            {
                conn.Close();
            }
        }
    }
}
