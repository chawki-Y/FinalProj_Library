﻿
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace finalproject
{
    public partial class User : Form
    {
        #region member objects

        DataTable tblCategories;
        DataTable tblbooks;
        Books books;
        Categories categories;
        bool ready = false;
        frmLogin parent;

        #endregion

        //constructor
        public User(frmLogin frm)
        {
            InitializeComponent();
            //initData();
            parent = frm;   
        }

        /*
        #region private methods
        private void initData()
        {
            books = new Books();
            categories = new Categories();
            tblbooks = new DataTable();
            populateCategories();
        }

        private void populateCategories()
        {
            ready = false;
            tblCategories = new DataTable();

            tblCategories = categories.getCategories();
            cmb_categories.DataSource = tblCategories;

            cmb_categories.ValueMember = "cat_ID";
            cmb_categories.DisplayMember = "cat_name";
            ready = true;
        }


        private void populateBooks()
        {
            ready = false;
            dg_books.DataSource = tblbooks;
            dg_books.Columns["ISBM"].Visible = false;
            dg_books.Columns["bk_cat_ID"].Visible = false;
            ready = true;
        }

        #endregion

        #region private events

        //handle cmobobox categories index changes, to display cars by category
        private void cmb_categories_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ready)
            {
                try
                {
                    int catid = int.Parse(cmb_categories.SelectedValue.ToString());
                    tblbooks = books.getBooksByCatID(catid);
                    populateBooks();
                }
                catch (MySqlException ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }


        #endregion

        private void txt_name_TextChanged(object sender, EventArgs e)
        {
            string name = txt_name.Text;
            tblbooks = books.getBooksByCatName(name);
            populateBooks();

        }*/

    }
}
