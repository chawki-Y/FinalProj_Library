﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace finalproject
{
    static class Utilities
    {
        public static int userId;
        public static string name;

    }
}
