﻿namespace finalproject
{
    partial class frmLogin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.panel_Login = new System.Windows.Forms.Panel();
            this.panel_SignUp = new System.Windows.Forms.Panel();
            this.btn_SignUpSignUp = new System.Windows.Forms.Button();
            this.txt_SignUpPwd = new System.Windows.Forms.TextBox();
            this.txt_SignUpUsername = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.btn_LoginLogin = new System.Windows.Forms.Button();
            this.txt_LoginPwd = new System.Windows.Forms.TextBox();
            this.txt_LoginUsername = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.btn_Login = new System.Windows.Forms.Button();
            this.btn_SignUp = new System.Windows.Forms.Button();
            this.btn_Guest = new System.Windows.Forms.Button();
            this.lbl_error = new System.Windows.Forms.Label();
            this.panel_Login.SuspendLayout();
            this.panel_SignUp.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Red;
            this.label1.Location = new System.Drawing.Point(100, 28);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(387, 44);
            this.label1.TabIndex = 0;
            this.label1.Text = "Welcome to LebRary";
            // 
            // panel_Login
            // 
            this.panel_Login.Controls.Add(this.lbl_error);
            this.panel_Login.Controls.Add(this.btn_LoginLogin);
            this.panel_Login.Controls.Add(this.txt_LoginPwd);
            this.panel_Login.Controls.Add(this.txt_LoginUsername);
            this.panel_Login.Controls.Add(this.label3);
            this.panel_Login.Controls.Add(this.label2);
            this.panel_Login.Location = new System.Drawing.Point(108, 173);
            this.panel_Login.Name = "panel_Login";
            this.panel_Login.Size = new System.Drawing.Size(379, 170);
            this.panel_Login.TabIndex = 1;
            this.panel_Login.Visible = false;
            // 
            // panel_SignUp
            // 
            this.panel_SignUp.Controls.Add(this.btn_SignUpSignUp);
            this.panel_SignUp.Controls.Add(this.txt_SignUpPwd);
            this.panel_SignUp.Controls.Add(this.txt_SignUpUsername);
            this.panel_SignUp.Controls.Add(this.label4);
            this.panel_SignUp.Controls.Add(this.label5);
            this.panel_SignUp.Location = new System.Drawing.Point(105, 173);
            this.panel_SignUp.Name = "panel_SignUp";
            this.panel_SignUp.Size = new System.Drawing.Size(379, 170);
            this.panel_SignUp.TabIndex = 6;
            this.panel_SignUp.Visible = false;
            // 
            // btn_SignUpSignUp
            // 
            this.btn_SignUpSignUp.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_SignUpSignUp.Location = new System.Drawing.Point(147, 131);
            this.btn_SignUpSignUp.Name = "btn_SignUpSignUp";
            this.btn_SignUpSignUp.Size = new System.Drawing.Size(75, 26);
            this.btn_SignUpSignUp.TabIndex = 5;
            this.btn_SignUpSignUp.Text = "Sign up";
            this.btn_SignUpSignUp.UseVisualStyleBackColor = true;
            // 
            // txt_SignUpPwd
            // 
            this.txt_SignUpPwd.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_SignUpPwd.Location = new System.Drawing.Point(107, 60);
            this.txt_SignUpPwd.Name = "txt_SignUpPwd";
            this.txt_SignUpPwd.PasswordChar = '*';
            this.txt_SignUpPwd.Size = new System.Drawing.Size(228, 22);
            this.txt_SignUpPwd.TabIndex = 3;
            // 
            // txt_SignUpUsername
            // 
            this.txt_SignUpUsername.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_SignUpUsername.Location = new System.Drawing.Point(107, 16);
            this.txt_SignUpUsername.Name = "txt_SignUpUsername";
            this.txt_SignUpUsername.Size = new System.Drawing.Size(228, 22);
            this.txt_SignUpUsername.TabIndex = 2;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(3, 63);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(96, 19);
            this.label4.TabIndex = 1;
            this.label4.Text = "Password :";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(3, 18);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(97, 19);
            this.label5.TabIndex = 0;
            this.label5.Text = "Username :";
            // 
            // btn_LoginLogin
            // 
            this.btn_LoginLogin.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_LoginLogin.Location = new System.Drawing.Point(144, 141);
            this.btn_LoginLogin.Name = "btn_LoginLogin";
            this.btn_LoginLogin.Size = new System.Drawing.Size(75, 26);
            this.btn_LoginLogin.TabIndex = 5;
            this.btn_LoginLogin.Text = "Login";
            this.btn_LoginLogin.UseVisualStyleBackColor = true;
            this.btn_LoginLogin.Click += new System.EventHandler(this.btn_LoginLogin_Click);
            // 
            // txt_LoginPwd
            // 
            this.txt_LoginPwd.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_LoginPwd.Location = new System.Drawing.Point(107, 60);
            this.txt_LoginPwd.Name = "txt_LoginPwd";
            this.txt_LoginPwd.PasswordChar = '*';
            this.txt_LoginPwd.Size = new System.Drawing.Size(228, 22);
            this.txt_LoginPwd.TabIndex = 3;
            // 
            // txt_LoginUsername
            // 
            this.txt_LoginUsername.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_LoginUsername.Location = new System.Drawing.Point(107, 16);
            this.txt_LoginUsername.Name = "txt_LoginUsername";
            this.txt_LoginUsername.Size = new System.Drawing.Size(228, 22);
            this.txt_LoginUsername.TabIndex = 2;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(3, 63);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(96, 19);
            this.label3.TabIndex = 1;
            this.label3.Text = "Password :";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(3, 18);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(97, 19);
            this.label2.TabIndex = 0;
            this.label2.Text = "Username :";
            // 
            // btn_Login
            // 
            this.btn_Login.Location = new System.Drawing.Point(108, 103);
            this.btn_Login.Name = "btn_Login";
            this.btn_Login.Size = new System.Drawing.Size(75, 23);
            this.btn_Login.TabIndex = 2;
            this.btn_Login.Text = "Login";
            this.btn_Login.UseVisualStyleBackColor = true;
            this.btn_Login.Click += new System.EventHandler(this.btn_Login_Click);
            // 
            // btn_SignUp
            // 
            this.btn_SignUp.Location = new System.Drawing.Point(252, 103);
            this.btn_SignUp.Name = "btn_SignUp";
            this.btn_SignUp.Size = new System.Drawing.Size(75, 23);
            this.btn_SignUp.TabIndex = 3;
            this.btn_SignUp.Text = "Sign up";
            this.btn_SignUp.UseVisualStyleBackColor = true;
            this.btn_SignUp.Click += new System.EventHandler(this.btn_SignUp_Click);
            // 
            // btn_Guest
            // 
            this.btn_Guest.Location = new System.Drawing.Point(397, 103);
            this.btn_Guest.Name = "btn_Guest";
            this.btn_Guest.Size = new System.Drawing.Size(75, 23);
            this.btn_Guest.TabIndex = 4;
            this.btn_Guest.Text = "Guest";
            this.btn_Guest.UseVisualStyleBackColor = true;
            // 
            // lbl_error
            // 
            this.lbl_error.AutoSize = true;
            this.lbl_error.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_error.ForeColor = System.Drawing.Color.Red;
            this.lbl_error.Location = new System.Drawing.Point(104, 105);
            this.lbl_error.Name = "lbl_error";
            this.lbl_error.Size = new System.Drawing.Size(195, 15);
            this.lbl_error.TabIndex = 6;
            this.lbl_error.Text = "Incorrect username or password";
            this.lbl_error.Visible = false;
            // 
            // frmLogin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.ClientSize = new System.Drawing.Size(583, 402);
            this.Controls.Add(this.panel_SignUp);
            this.Controls.Add(this.btn_Guest);
            this.Controls.Add(this.btn_SignUp);
            this.Controls.Add(this.btn_Login);
            this.Controls.Add(this.panel_Login);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "frmLogin";
            this.Text = "frmLogin";
            this.panel_Login.ResumeLayout(false);
            this.panel_Login.PerformLayout();
            this.panel_SignUp.ResumeLayout(false);
            this.panel_SignUp.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel_Login;
        private System.Windows.Forms.Panel panel_SignUp;
        private System.Windows.Forms.Button btn_SignUpSignUp;
        private System.Windows.Forms.TextBox txt_SignUpPwd;
        private System.Windows.Forms.TextBox txt_SignUpUsername;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button btn_LoginLogin;
        private System.Windows.Forms.TextBox txt_LoginPwd;
        private System.Windows.Forms.TextBox txt_LoginUsername;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btn_Login;
        private System.Windows.Forms.Button btn_SignUp;
        private System.Windows.Forms.Button btn_Guest;
        private System.Windows.Forms.Label lbl_error;
    }
}