﻿
using System;
using System.Data;
using System.Text;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace finalproject
{
    public partial class frmLogin : Form
    {
        public frmLogin()
        {
            InitializeComponent();
        }

        private void resetLoginInputs()
        {
            txt_LoginUsername.Text = "";
            txt_LoginPwd.Text = "";
        }

        private void resetSignUpInputs()
        {
            txt_SignUpUsername.Text = "";
            txt_SignUpPwd.Text = "";
        }

        private void btn_Login_Click(object sender, EventArgs e)
        {
            panel_Login.Visible = true;
            resetSignUpInputs();

            panel_SignUp.Visible = false;

        }

        private void btn_SignUp_Click(object sender, EventArgs e)
        {
            panel_SignUp.Visible = true;
            resetLoginInputs();

            panel_Login.Visible = false;
        }

        private void btn_LoginLogin_Click(object sender, EventArgs e)
        {
            int utype = 0;

            try
            {
                string username = txt_LoginUsername.Text;
                string pwd = txt_LoginPwd.Text;

                Clients users = new Clients();

                DataRow result = users.login(username, pwd);

                if (result != null)
                {
                    utype = int.Parse(result["client_type"].ToString());
                    Utilities.userId = int.Parse(result["client_ID"].ToString());
                    Utilities.name = result["client_fname"].ToString();
                    
                }

                switch (utype)
                {
                    case 0: //wrong username or pwd
                        lbl_error.Visible = true;
                        resetLoginInputs();
                        break;
                    case 1: //normal client
                        resetLoginInputs();
                        lbl_error.Visible = false;
                        User user = new User(this);                                             
                        this.Hide();
                        break;
                    case 2: //admin
                        resetLoginInputs();
                        lbl_error.Visible = false;
                        Admin admin = new Admin(this);
                        admin.Show();
                        this.Hide();                      
                        break;
                }
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
