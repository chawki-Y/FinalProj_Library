﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace finalproject
{
    public partial class frmMain : Form
    {
        Clients clients;
        Books books;
        Categories categories;
        DataTable tblclients;
        DataTable tblbooks;
        DataTable tblCategories;
        bool ready;
        int uID;
        frmLogin parent;

        public frmMain(frmLogin frm)
        {
            InitializeComponent();
            parent = frm;
            InitData();
        }

        void InitData()
        {
            clients = new Clients();
            books = new Books();
            categories = new Categories();
            ready = false;
            getCategories();
        }

        private void getClients()
        {
            ready = false;
            tblclients = clients.getClients();
            dgVClients.DataSource = tblclients;

            dgVClients.Columns["client_ID"].Visible = false;
            dgVClients.Columns["client_type"].Visible = false;
            ready = true;

        }

        private void getBooks()
        {
            ready = false;
            tblbooks = books.getBooks();
            dgVClients.DataSource = tblbooks;

            dgVClients.Columns["ISBN"].Visible = false;
            dgVClients.Columns["bk_cat_id"].Visible = false;
            dgVClients.Columns["bk_author_ID"].Visible = false;
            dgVClients.Columns["cat_ID"].Visible = false;
            ready = true;

        }

        private void getCategories()
        {
            ready = false;
            tblCategories = categories.getCategories();
            cmb_categories.DataSource = tblCategories;

            cmb_categories.ValueMember = "cat_ID";
            cmb_categories.DisplayMember = "cat_name";
            ready = true;

        }

        private void btn_delete_Click(object sender, EventArgs e)
        {
            int index = dgVClients.SelectedRows[0].Index;

            int id = int.Parse(tblclients.Rows[index]["client_ID"].ToString());

            clients.deleteClientByID(id);
            getClients();

        }

        private void usersToolStripMenuItem_Click(object sender, EventArgs e)
        {
            getClients();
        }

        private void dgVClients_SelectionChanged(object sender, EventArgs e)
        {
            if (ready)
            {
                int index = dgVClients.SelectedRows[0].Index;
                /*uID = int.Parse(tblclients.Rows[index]["u_id"].ToString());
                txt_uname.Text = tblclients.Rows[index]["username"].ToString();
                txt_pwd.Text = tblclients.Rows[index]["pwd"].ToString();
                txt_type.Text = tblclients.Rows[index]["u_type"].ToString();
                */
                MessageBox.Show(tblbooks.Rows[index]["bk_cat_ID"].ToString());
                txt_uname.Text = tblbooks.Rows[index]["bk_name"].ToString();
                txt_pwd.Text = tblbooks.Rows[index]["bk_price"].ToString();
                cmb_categories.SelectedValue = int.Parse(tblbooks.Rows[index]["bk_cat_ID"].ToString());
            }
        }

        private void btn_update_Click(object sender, EventArgs e)
        {
            string uname = txt_uname.Text;
            string pwd = txt_pwd.Text;
            int type = int.Parse(txt_type.Text);

            clients.updateClients(uID, pwd, type);
            getClients();
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            parent.Show();
            this.Close();          
        }

        private void clientsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            getBooks();
        }

        
    }
}
