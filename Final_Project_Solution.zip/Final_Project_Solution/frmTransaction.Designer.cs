﻿namespace finalproject
{
    partial class frmTransaction
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.cmb_cats = new System.Windows.Forms.ComboBox();
            this.cmb_Books = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.lb_Client = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // cmb_cats
            // 
            this.cmb_cats.FormattingEnabled = true;
            this.cmb_cats.Location = new System.Drawing.Point(99, 46);
            this.cmb_cats.Margin = new System.Windows.Forms.Padding(2);
            this.cmb_cats.Name = "cmb_cats";
            this.cmb_cats.Size = new System.Drawing.Size(92, 21);
            this.cmb_cats.TabIndex = 0;
            this.cmb_cats.SelectedIndexChanged += new System.EventHandler(this.cmb_cats_SelectedIndexChanged);
            // 
            // cmb_Books
            // 
            this.cmb_Books.FormattingEnabled = true;
            this.cmb_Books.Location = new System.Drawing.Point(286, 48);
            this.cmb_Books.Margin = new System.Windows.Forms.Padding(2);
            this.cmb_Books.Name = "cmb_Books";
            this.cmb_Books.Size = new System.Drawing.Size(92, 21);
            this.cmb_Books.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(29, 50);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(56, 13);
            this.label1.TabIndex = 2;
            this.label1.Text = "categories";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(242, 50);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(37, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "Books";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(442, 190);
            this.button1.Margin = new System.Windows.Forms.Padding(2);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(56, 19);
            this.button1.TabIndex = 4;
            this.button1.Text = "button1";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // lb_Client
            // 
            this.lb_Client.AutoSize = true;
            this.lb_Client.BackColor = System.Drawing.Color.Red;
            this.lb_Client.Location = new System.Drawing.Point(524, 7);
            this.lb_Client.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lb_Client.Name = "lb_Client";
            this.lb_Client.Size = new System.Drawing.Size(56, 13);
            this.lb_Client.TabIndex = 5;
            this.lb_Client.Text = "categories";
            // 
            // frmTransaction
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(600, 366);
            this.Controls.Add(this.lb_Client);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.cmb_Books);
            this.Controls.Add(this.cmb_cats);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "frmTransaction";
            this.Text = "frmTransaction";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox cmb_cats;
        private System.Windows.Forms.ComboBox cmb_Books;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label lb_Client;
    }
}