﻿using System;
using System.Data;
using System.Text;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace finalproject
{
    public partial class frmTransaction : Form
    {
        DataTable tblCategories;
        DataTable tblbooks;
        Books books;
        Categories categories;
        bool ready = false;

        public frmTransaction()
        {
            InitializeComponent();
            initData();
        }

        private void initData()
        {
            books = new Books();
            categories = new Categories();
            tblbooks = new DataTable();
            tblCategories = new DataTable();
            populateCategories();
            lb_Client.Text = Utilities.name;
        }

        private void populateCategories()
        {
            ready = false;
            tblCategories = new DataTable();

            tblCategories = categories.getCategories();
            cmb_cats.DataSource = tblCategories;

            cmb_cats.ValueMember = "cat_ID";
            cmb_cats.DisplayMember = "cat_name";
            ready = true;
        }

        private void populateBooks(int catid)
        {
            try
            {
                ready = false;
                cmb_Books.DataSource = null;

                tblbooks = books.getBooksByCatID(catid);
                cmb_Books.DataSource = tblbooks;

                cmb_Books.ValueMember = "ISBM";
                cmb_Books.DisplayMember = "bk_name";
                ready = true;
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void cmb_cats_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ready)
            {
                try
                {
                    int catid = int.Parse(cmb_cats.SelectedValue.ToString());
                    populateBooks(catid);
                }
                catch (MySqlException ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int x = Utilities.userId;


        }

    }
}
